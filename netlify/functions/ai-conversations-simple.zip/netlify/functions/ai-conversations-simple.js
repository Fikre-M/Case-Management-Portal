var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var ai_conversations_simple_exports = {};
__export(ai_conversations_simple_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(ai_conversations_simple_exports);
var import_jsonwebtoken = __toESM(require("jsonwebtoken"), 1);
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-change-in-production";
const conversations = [];
const handleResponse = (callback, statusCode, body) => {
  callback(null, {
    statusCode,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });
};
const handleCORS = (callback) => {
  handleResponse(callback, 200, {});
};
const verifyToken = (event) => {
  const token = event.headers?.authorization?.replace("Bearer ", "");
  if (!token) {
    throw new Error("Access denied. No token provided.");
  }
  try {
    return import_jsonwebtoken.default.verify(token, JWT_SECRET);
  } catch (error) {
    throw new Error("Invalid token");
  }
};
const handler = async (event, context, callback) => {
  if (event.httpMethod === "OPTIONS") {
    return handleCORS(callback);
  }
  if (event.httpMethod !== "POST") {
    return handleResponse(callback, 405, { error: "Method not allowed" });
  }
  try {
    const user = verifyToken(event);
    const { title, category } = JSON.parse(event.body);
    const conversation = {
      id: Date.now().toString(),
      userId: user.userId,
      title: title || "New Conversation",
      category: category || "general",
      messages: [],
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
    };
    conversations.push(conversation);
    return handleResponse(callback, 201, conversation);
  } catch (error) {
    console.error("Create conversation error:", error);
    if (error.message.includes("Access denied") || error.message.includes("Invalid token")) {
      return handleResponse(callback, 401, { error: error.message });
    }
    return handleResponse(callback, 500, { error: "Failed to create conversation" });
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
