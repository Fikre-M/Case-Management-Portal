var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var ai_conversations_exports = {};
__export(ai_conversations_exports, {
  createConversation: () => import_ai.createConversation,
  getConversations: () => import_ai.getConversations
});
module.exports = __toCommonJS(ai_conversations_exports);
var import_ai = require("./ai.js");
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createConversation,
  getConversations
});
