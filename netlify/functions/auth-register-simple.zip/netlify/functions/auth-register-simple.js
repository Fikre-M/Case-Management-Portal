var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var auth_register_simple_exports = {};
__export(auth_register_simple_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(auth_register_simple_exports);
var import_bcryptjs = __toESM(require("bcryptjs"), 1);
var import_jsonwebtoken = __toESM(require("jsonwebtoken"), 1);
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-change-in-production";
const users = [];
const handleResponse = (callback, statusCode, body) => {
  callback(null, {
    statusCode,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });
};
const handleCORS = (callback) => {
  handleResponse(callback, 200, {});
};
const handler = async (event, context, callback) => {
  if (event.httpMethod === "OPTIONS") {
    return handleCORS(callback);
  }
  if (event.httpMethod !== "POST") {
    return handleResponse(callback, 405, { error: "Method not allowed" });
  }
  try {
    const { username, email, password } = JSON.parse(event.body);
    if (!username || !email || !password) {
      return handleResponse(callback, 400, { error: "All fields are required" });
    }
    const existingUser = users.find((u) => u.email === email);
    if (existingUser) {
      return handleResponse(callback, 400, { error: "User already exists" });
    }
    const saltRounds = 12;
    const hashedPassword = await import_bcryptjs.default.hash(password, saltRounds);
    const user = {
      id: Date.now().toString(),
      username,
      email,
      password: hashedPassword,
      role: "user",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    users.push(user);
    const token = import_jsonwebtoken.default.sign(
      { userId: user.id, username: user.username },
      JWT_SECRET,
      { expiresIn: "7d" }
    );
    return handleResponse(callback, 201, {
      message: "User created successfully",
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    console.error("Registration error:", error);
    return handleResponse(callback, 500, { error: "Registration failed" });
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
