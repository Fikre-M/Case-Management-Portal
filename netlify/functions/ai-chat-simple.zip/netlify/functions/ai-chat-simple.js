var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var ai_chat_simple_exports = {};
__export(ai_chat_simple_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(ai_chat_simple_exports);
var import_jsonwebtoken = __toESM(require("jsonwebtoken"), 1);
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-change-in-production";
const conversations = [];
const usage = [];
const handleResponse = (callback, statusCode, body) => {
  callback(null, {
    statusCode,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });
};
const handleCORS = (callback) => {
  handleResponse(callback, 200, {});
};
const verifyToken = (event) => {
  const token = event.headers?.authorization?.replace("Bearer ", "");
  if (!token) {
    throw new Error("Access denied. No token provided.");
  }
  try {
    return import_jsonwebtoken.default.verify(token, JWT_SECRET);
  } catch (error) {
    throw new Error("Invalid token");
  }
};
function getMockResponse(message) {
  const lowerMessage = message.toLowerCase();
  if (lowerMessage.match(/\b(hi|hello|hey|greetings)\b/)) {
    return "Hello! I'm here to help you with your legal case management needs. What would you like to know?";
  }
  if (lowerMessage.match(/\b(case|cases|litigation|lawsuit)\b/)) {
    return "I can help you with case management in several ways: Case Analysis, Document Drafting, Research, Timeline Management, and Client Communication. What specific aspect would you like help with?";
  }
  return "I'm here to help! I specialize in case management and analysis, appointment scheduling, document drafting, legal research, and client communication. Could you clarify how I can help with your specific need?";
}
const handler = async (event, context, callback) => {
  if (event.httpMethod === "OPTIONS") {
    return handleCORS(callback);
  }
  if (event.httpMethod !== "POST") {
    return handleResponse(callback, 405, { error: "Method not allowed" });
  }
  try {
    const user = verifyToken(event);
    const { message, conversationId } = JSON.parse(event.body);
    if (!message) {
      return handleResponse(callback, 400, { error: "Message is required" });
    }
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    const existingUsage = usage.find((u) => u.userId === user.userId && u.date === today);
    if (existingUsage) {
      existingUsage.requestCount++;
      existingUsage.lastRequest = (/* @__PURE__ */ new Date()).toISOString();
    } else {
      usage.push({
        userId: user.userId,
        date: today,
        requestCount: 1,
        tokensUsed: 0,
        lastRequest: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    const response = getMockResponse(message);
    if (conversationId) {
      const conv = conversations.find((c) => c.id === conversationId);
      if (conv) {
        conv.messages.push(
          { type: "user", content: message, timestamp: (/* @__PURE__ */ new Date()).toISOString() },
          { type: "assistant", content: response, timestamp: (/* @__PURE__ */ new Date()).toISOString() }
        );
        conv.lastUpdated = (/* @__PURE__ */ new Date()).toISOString();
      }
    }
    return handleResponse(callback, 200, { response });
  } catch (error) {
    console.error("AI chat error:", error);
    if (error.message.includes("Access denied") || error.message.includes("Invalid token")) {
      return handleResponse(callback, 401, { error: error.message });
    }
    return handleResponse(callback, 500, { error: "Failed to get AI response" });
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
