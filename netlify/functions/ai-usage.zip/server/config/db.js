var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var db_exports = {};
__export(db_exports, {
  Conversation: () => Conversation,
  Usage: () => Usage,
  User: () => User,
  connectDB: () => connectDB,
  getModels: () => getModels,
  initializeModels: () => initializeModels
});
module.exports = __toCommonJS(db_exports);
var import_mongoose = __toESM(require("mongoose"), 1);
const memoryStorage = {
  users: [],
  conversations: [],
  usage: []
};
const connectDB = async () => {
  try {
    const mongoUri = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/aidflow";
    const conn = await import_mongoose.default.connect(mongoUri);
    console.log(`\u2705 MongoDB Connected: ${conn.connection.host}`);
    return true;
  } catch (error) {
    console.warn("\u26A0\uFE0F MongoDB connection failed, using in-memory storage:", error.message);
    return false;
  }
};
const createMockModels = () => {
  return {
    User: {
      findOne: async (query) => {
        const user = memoryStorage.users.find((u) => u.email === query.email);
        return user || null;
      },
      create: async (data) => {
        const user = {
          ...data,
          _id: Date.now().toString(),
          createdAt: /* @__PURE__ */ new Date(),
          role: data.role || "user"
        };
        memoryStorage.users.push(user);
        return user;
      }
    },
    Conversation: {
      findByIdAndUpdate: async (id, update) => {
        const conv = memoryStorage.conversations.find((c) => c._id === id);
        if (conv && update.$push) {
          conv.messages.push(...update.$push.messages);
          conv.lastUpdated = /* @__PURE__ */ new Date();
        }
        return conv || null;
      },
      create: async (data) => {
        const conv = {
          ...data,
          _id: Date.now().toString(),
          createdAt: /* @__PURE__ */ new Date(),
          lastUpdated: /* @__PURE__ */ new Date(),
          messages: data.messages || []
        };
        memoryStorage.conversations.push(conv);
        return conv;
      },
      find: async (query) => {
        return memoryStorage.conversations.filter((c) => c.userId === query.userId);
      },
      findOne: async (query) => {
        return memoryStorage.conversations.find((c) => c._id === query.id) || null;
      },
      deleteOne: async (query) => {
        const index = memoryStorage.conversations.findIndex((c) => c._id === query._id);
        if (index > -1) {
          memoryStorage.conversations.splice(index, 1);
          return { deletedCount: 1 };
        }
        return { deletedCount: 0 };
      }
    },
    Usage: {
      findOneAndUpdate: async (query, update, options = {}) => {
        const existing = memoryStorage.usage.find((u) => u.userId === query.userId && u.date === query.date);
        if (existing && update.$inc) {
          Object.keys(update.$inc).forEach((key) => {
            existing[key] = (existing[key] || 0) + update.$inc[key];
          });
          if (update.$set) {
            Object.assign(existing, update.$set);
          }
          return existing;
        } else if (!existing && options.upsert) {
          const usage = {
            userId: query.userId,
            date: query.date,
            requestCount: 0,
            tokensUsed: 0,
            lastRequest: /* @__PURE__ */ new Date(),
            ...update.$set,
            ...update.$inc || {}
          };
          memoryStorage.usage.push(usage);
          return usage;
        }
        return existing || null;
      },
      find: async (query) => {
        return memoryStorage.usage.filter((u) => u.userId === query.userId);
      }
    }
  };
};
let User, Conversation, Usage;
let isUsingMongoDB = false;
const getModels = async () => {
  if (isUsingMongoDB) {
    return { User, Conversation, Usage };
  }
  const mongoConnected = await connectDB();
  if (mongoConnected) {
    const userSchema = new import_mongoose.default.Schema({
      username: { type: String, required: true, unique: true },
      email: { type: String, required: true, unique: true },
      password: { type: String, required: true },
      role: { type: String, enum: ["user", "admin"], default: "user" },
      createdAt: { type: Date, default: Date.now }
    });
    const conversationSchema = new import_mongoose.default.Schema({
      userId: { type: import_mongoose.default.Schema.Types.ObjectId, ref: "User", required: true },
      title: { type: String, required: true },
      category: { type: String, default: "general" },
      messages: [{
        type: { type: String, enum: ["user", "assistant"], required: true },
        content: { type: String, required: true },
        timestamp: { type: Date, default: Date.now }
      }],
      createdAt: { type: Date, default: Date.now },
      lastUpdated: { type: Date, default: Date.now }
    });
    const usageSchema = new import_mongoose.default.Schema({
      userId: { type: import_mongoose.default.Schema.Types.ObjectId, ref: "User", required: true },
      requestCount: { type: Number, default: 0 },
      tokensUsed: { type: Number, default: 0 },
      lastRequest: { type: Date, default: Date.now },
      date: { type: String, required: true }
    });
    User = import_mongoose.default.model("User", userSchema);
    Conversation = import_mongoose.default.model("Conversation", conversationSchema);
    Usage = import_mongoose.default.model("Usage", usageSchema);
    isUsingMongoDB = true;
    console.log("\u2705 Using MongoDB models");
    return { User, Conversation, Usage };
  } else {
    const mockModels = createMockModels();
    User = mockModels.User;
    Conversation = mockModels.Conversation;
    Usage = mockModels.Usage;
    console.log("\u2705 Using in-memory models");
    return { User, Conversation, Usage };
  }
};
let models = null;
const initializeModels = async () => {
  if (models) return models;
  models = await getModels();
  return models;
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Conversation,
  Usage,
  User,
  connectDB,
  getModels,
  initializeModels
});
