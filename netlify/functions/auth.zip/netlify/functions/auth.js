var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var auth_exports = {};
__export(auth_exports, {
  login: () => login,
  register: () => register
});
module.exports = __toCommonJS(auth_exports);
var import_bcryptjs = __toESM(require("bcryptjs"), 1);
var import_jsonwebtoken = __toESM(require("jsonwebtoken"), 1);
var import_db = require("../../server/config/db.js");
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-change-in-production";
const handleResponse = (callback, statusCode, body) => {
  callback(null, {
    statusCode,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });
};
const handleCORS = (callback) => {
  handleResponse(callback, 200, {});
};
const register = async (event, context, callback) => {
  if (event.httpMethod === "OPTIONS") {
    return handleCORS(callback);
  }
  if (event.httpMethod !== "POST") {
    return handleResponse(callback, 405, { error: "Method not allowed" });
  }
  try {
    await (0, import_db.connectDB)();
    const { User } = await (0, import_db.getModels)();
    const { username, email, password } = JSON.parse(event.body);
    if (!username || !email || !password) {
      return handleResponse(callback, 400, { error: "All fields are required" });
    }
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return handleResponse(callback, 400, { error: "User already exists" });
    }
    const saltRounds = 12;
    const hashedPassword = await import_bcryptjs.default.hash(password, saltRounds);
    const user = await User.create({
      username,
      email,
      password: hashedPassword
    });
    const token = import_jsonwebtoken.default.sign(
      { userId: user._id, username: user.username },
      JWT_SECRET,
      { expiresIn: "7d" }
    );
    return handleResponse(callback, 201, {
      message: "User created successfully",
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    console.error("Registration error:", error);
    return handleResponse(callback, 500, { error: "Registration failed" });
  }
};
const login = async (event, context, callback) => {
  if (event.httpMethod === "OPTIONS") {
    return handleCORS(callback);
  }
  if (event.httpMethod !== "POST") {
    return handleResponse(callback, 405, { error: "Method not allowed" });
  }
  try {
    await (0, import_db.connectDB)();
    const { User } = await (0, import_db.getModels)();
    const { email, password } = JSON.parse(event.body);
    if (!email || !password) {
      return handleResponse(callback, 400, { error: "Email and password are required" });
    }
    const user = await User.findOne({ email });
    if (!user) {
      return handleResponse(callback, 401, { error: "Invalid credentials" });
    }
    const isValidPassword = await import_bcryptjs.default.compare(password, user.password);
    if (!isValidPassword) {
      return handleResponse(callback, 401, { error: "Invalid credentials" });
    }
    const token = import_jsonwebtoken.default.sign(
      { userId: user._id, username: user.username },
      JWT_SECRET,
      { expiresIn: "7d" }
    );
    return handleResponse(callback, 200, {
      message: "Login successful",
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    console.error("Login error:", error);
    return handleResponse(callback, 500, { error: "Login failed" });
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  login,
  register
});
